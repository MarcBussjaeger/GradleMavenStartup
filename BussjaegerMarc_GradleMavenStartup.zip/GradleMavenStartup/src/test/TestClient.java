import org.junit.Test;
import static org.junit.Assert.*;
import mainClass.Main;

public class TestClient{
	@Test
	public void swapCaseFunctionality(){
		assertTrue(Main.swap("UP down").equals("up DOWN"));
	}
}
