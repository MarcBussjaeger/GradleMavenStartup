package mainClass;

import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;

public class Main{
	public static void main(String[] args){
		if(args.length < 1){
			System.out.println("please add at least one string as argument");
		} else {
			String s = Arrays.toString(args);
			System.out.println("Hello there!\nYour input was:\n" + s
				+ "\n\nbut I'm going to print it like this:\n"
				+ swap(s)
				+ "\n\nI know... I'm mean ;)");
		}
	}
	
	public static String swap(String s){
		return StringUtils.swapCase(s);
	}
}
